import sys
import os
from tkinter import *


window=Tk()
window.title("Running Python Script")
window.geometry('575x546')

img = PhotoImage(file="../testruns/vought.PNG")
label = Label(
    window,
    image=img
)
label.place(x=0, y=0)
def run():
    os.system('../testruns/login.py')

btn = Button(window, text="Get Started!!.", bg="white", fg="black",command=run )
btn.grid(column=0, row=0)
btn.place(x=255,y=390)

window.mainloop()

