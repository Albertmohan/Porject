import sys
import os
from tkinter import *


window=Tk()
window.title("Running Python Script")
window.geometry('575x546')

img = PhotoImage(file="vought.png")
label = Label(
    window,
    image=img
)
label.place(x=0, y=0)
def run():
    os.system('login.py')

btn = Button(window, text="Click Me", bg="white", fg="black",command=run )
btn.grid(column=0, row=0)
btn.place(x=160,y=50)

window.mainloop()