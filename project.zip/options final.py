from tkinter import *
import os
from tkinter import ttk
import random

root= Tk()
root.title("Vought+")
root.geometry("800x700")
photo = PhotoImage(file="Vought logo.png")
label = Label(image=photo)
label.pack()
b1=Button(root,text="Lyrics")
b2=Button(root,text="Music")
b1.pack(side=LEFT)
b2.pack(side=LEFT)


def run():
    os.system('Lyrics.py')
b1.configure(root,command=run)
def run1():
    os.system('music.py')
b2.configure(root,command=run1)


root.mainloop()